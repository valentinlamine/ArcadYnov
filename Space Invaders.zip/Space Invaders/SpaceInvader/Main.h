#include<SFML/Graphics.hpp>
#include<iostream>
#include"perso.cpp"

